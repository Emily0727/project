# HELLLLLLO.

**✅ This is the easiest game to set up and play. Literally. No registrarion, no SMS, no singing in.
JUST DO IT.
CATCH THEM AAALLLLLL.**

🦝 This game is inspired by raccoons and TimHortons.
You find the raccoons, you KILL 🔪 them. Mercilessly.

To kill, just click on the raccoon. DONT LET THEM GET A SINGLE DONUT!
You only have four donuts🍩: you lose them all, you LOSE.

You don't have to work at all, get free labor from the gacha!

After getting them, you can use them during the game by dragging them to the sides of the donuts.

There are three types of employees, from least to most effective:
- The cashier (Blue) 👶🔵
- The manager (Red) 👨‍💼🔴
- The Boss (Green) 🤴🟢

🎰 Gacha costs raccoons, but don't worry - it's very easy to get them, and you can also get some while gachaing! Great, isn't it?

🎶 The music in this game is authentic and made by yours truly.
🎨 The art is made by the amazing Annie Liang, with a tiny bit of help from Emily Yuan and Nika Pomazova.

## This project was made with love and humour. ❤️

Enjoy and have fun!🥳
